/*Chương 3 - Bài 88 - trang 27*/

#include <stdio.h>

int main() {
	for(int i = 'a'; i <= 'z'; ++i) {
		printf("%2c", i);
	}
}
