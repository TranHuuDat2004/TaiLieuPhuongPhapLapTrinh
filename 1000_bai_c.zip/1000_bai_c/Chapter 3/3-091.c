/*Chương 3 - Bài 91 - trang 33*/

#include <stdio.h>

int main() {
	int i = 1;

	while(i < 100) {
		printf("%3d ", i);
		i = i + 2;
	}
}
