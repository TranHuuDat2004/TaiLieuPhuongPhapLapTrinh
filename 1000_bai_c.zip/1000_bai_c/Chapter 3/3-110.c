/*Chương 3 - Bài 110 - trang 39*/

#include <stdio.h>

int main() {
	int s = 200000;
	int a1 = 1000, a2 = 2000, a3 = 5000;
	printf("%d x %d = %d \n", a1, s/a1, s);
	printf("%d x %d = %d \n", a2, s/a2, s);
	printf("%d x %d = %d \n", a3, s/a3, s);
}
