/*
 *  Unit13_FreezerTemp.c
 *  From Unit 4 Exercise 6: Estimate temperature in a freezer
 *  given the elapsed time since power failure.
 *  Formula: T = (4*t^10 / (t^9+2)) - 20
 */
#include <math.h>

// Compute new temperature in freezer
float calc_temperature(float hr) {
	return ((4.0 * pow(hr, 10.0))/(pow(hr, 9.0) + 2.0)) - 20.0;
}

