/*
 *  Unit13_FreezerTemp.h
 *  From Unit 4 Exercise 6: Estimate temperature in a freezer
 *  given the elapsed time since power failure.
 *  Formula: T = (4*t^10 / (t^9+2)) - 20
 */

// Compute new temperature in freezer
float calc_temperature(float hr);

