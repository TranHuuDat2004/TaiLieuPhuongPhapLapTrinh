// Unit14_Example1.c 
#include <stdio.h>

//prototype
void f(int, int, int);

int main(void) {
	int a = 9, b = -2, c = 5;

	f(a, b, c);//x = 7; y = -4; z = 3
	printf("a = %d, b = %d, c = %d\n", a, b, c);//9 -2 5 

	return 0;
}

//function definition
void f(int x, int y, int z) {
	//x is value
	x = x - 2;
	y = y - 2;
	z = z - 2;
	printf("x = %d, y = %d, z = %d\n", x, y, z);
}

