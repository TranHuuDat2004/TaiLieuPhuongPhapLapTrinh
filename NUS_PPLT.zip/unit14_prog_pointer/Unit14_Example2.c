// Unit14_Example2.c 
#include <stdio.h>

//pass by pointer, reference
void f(int *, int *, int *);
void swap(int *x, int *y);

int main(void) {
	// int a = 9, b = -2, c = 5;

	// f(&a, &b, &c);//11, 0, 7
	// printf("a = %d, b = %d, c = %d\n", a, b, c);//9 -2 5 ???

	int x = 5;
	int y = 10;

	swap (&x, &y);// x = 10, y = 5
	printf("x = %d, y = %d", x, y);

	return 0;
}

void swap(int *x, int *y){
	int temp;

	temp = *x;
	*x = *y;
	*y = temp;

	printf("x = %d, y = %d\n", *x, *y);
}
void f(int *x, int *y, int *z) {
	//x is address
	//value at address is *pointer_name;
	*x = *x + 2;
	*y = *y + 2;
	*z = *z + 2;
	printf("*x = %d, *y = %d, *z = %d\n", *x, *y, *z);
}

