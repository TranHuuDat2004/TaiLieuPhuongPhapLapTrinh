// Unit14_Max_and_Average_v1.c 
#include <stdio.h>

int findMaximum(int [], int);
double findAverage(int [], int);
void multiply2x(int[], int);
void printArray(int[], int);
void reverseArray(int[], int);


int main(void) {
	int numbers[] = { 1, 5, 3, 6, 3, 2, 1, 9, 8, 3 };
	//int numbers[] = { 1, 5, 7, 8, 10, 12, 15, 18, 20, 22 };

	int max = findMaximum(numbers, 10);
	double ave = findAverage(numbers, 10);

	// printf("Before\n");
	// printArray(numbers, 10);
	
	// //multiply2x(numbers, 10);
	// reverseArray(numbers, 10);

	// printf("After\n");
	// printArray(numbers, 10);

	printf("max = %d, average = %.2f\n", max, ave);
	return 0;
}

void printArray(int arr[], int size){
	int i;
	printf("Print Array: ");
	for(i = 0; i < size; i++){
		printf("%d ", arr[i]);
	}
}

void reverseArray(int arr[], int size){
	//case 1
	// int temp[size];
	// int i;
	// int j = 0;
	// for(i = size - 1; i >=0; i--){
	// 	temp[j] = arr[i];
	// 	j = j + 1;
	// }
	// for(i = 0; i < size; i++){
	// 	arr[i] = temp[i];
	// }

	//case 2
	int i = 0;
	int j = size - 1;
	int temp;
	while (i < j){
		temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;

		i = i + 1;
		j = j - 1;
	}
}

void multiply2x(int arr[], int size){
	int i;

	for(i = 0; i < size; i++){
		arr[i] = arr[i] * 2;
	}
}
// Compute maximum value in arr
// Precond: size > 0
int findMaximum(int arr[], int size) {
	int i, max;

	max = arr[0];
	for (i=1; i<size; i++) {
		if (arr[i] > max)
			max = arr[i];
	}
	return max;
}

// Compute average value in arr
// Precond: size > 0
double findAverage(int arr[], int size) {
	int i;
	double sum = 0.0;//float

	for (i=0; i<size; i++) {
		sum += arr[i];
	}
	return sum/size;
}

