// Unit14_Max_and_Average_v2.c 
#include <stdio.h>

//How to return 2 value by pointer parameter
void findMaxAndAverage(int [], int, int *, double *);

int main(void) {
	int numbers[10] = { 1, 5, 3, 6, 3, 2, 1, 9, 8, 3 };
	int max;
	double ave;

	findMaxAndAverage(numbers, 10, &max, &ave);//call return 2 values

	printf("max = %d, average = %.2f\n", max, ave);
	return 0;
}

// Compute maximum value and average value in arr
// Precond: size > 0
void findMaxAndAverage(int arr[], int size, 
			int *max_ptr, double *ave_ptr) {
	int i;
	double sum = 0.0;

	*max_ptr = arr[0];
	for (i=0; i<size; i++) {
		//find max
		if (arr[i] > *max_ptr) {
			*max_ptr = arr[i];
		}
		//calc sum
		sum += arr[i];
	}
	*ave_ptr = sum/size;
}

