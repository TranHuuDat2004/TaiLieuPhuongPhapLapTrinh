// Unit14_Print_v2.c 
// This program shows printing of values of variables 
// through a function with address parameters.
#include <stdio.h>

//How to pass by pointer
void print_values(int *, int *);

int main(void) {
	int num1 = 1, num2 = 2;

	print_values(&num1, &num2);

	return  0;
}

// Print values
void print_values(int *n1_ptr, int *n2_ptr) {
	*n1_ptr = *n1_ptr * 2;
	
	printf("Values: %d and %d\n", *n1_ptr, *n2_ptr);
}

