// Unit14_Swap_v1.c 
#include <stdio.h>

int main(void) {
	int var1, var2, temp;

	printf("Enter two integers: ");
	scanf("%d %d", &var1, &var2);

	// Swap the values
	temp = var1;
	var1 = var2;
	var2 = temp;

	printf("var = %d; var2 = %d\n", var1, var2);
	return 0;
}

