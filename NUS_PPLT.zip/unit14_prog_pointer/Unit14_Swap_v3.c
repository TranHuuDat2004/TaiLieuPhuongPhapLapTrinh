// Unit14_Swap_v3.c 
// Corrected modularised version of Unit14_Swap.c
#include <stdio.h>

//Change after swap
void swap(int *, int *);

int main(void) {
	int var1, var2;

	printf("Enter two integers: ");
	scanf("%d %d", &var1, &var2);

	swap(&var1, &var2); 

	printf("var = %d; var2 = %d\n", var1, var2);
	return 0;
}

//pointer
void swap(int *val1_ptr, int *val2_ptr) {
	int temp;

	temp = *val1_ptr;
	*val1_ptr = *val2_ptr;
	*val2_ptr = temp;
}

