// Unit15_Perimeter_Complete.c
// This program reads the lengths of the sides of a rectangle,
// and computes the minimum perimeter after folding the rectangle
// once along the x-axis or y-axis.
// Aaron Tan
#include <stdio.h>

typedef struct {
	int side1, side2;
} rectangle_t;

int main(void) {
	rectangle_t rect;
	int perimeter;

	printf("Enter lengths: ");
	scanf("%d %d", &rect.side1, &rect.side2);

	if (rect.side1 > rect.side2)
		perimeter = rect.side1 + 2*rect.side2;
	else
		perimeter = rect.side2 + 2*rect.side1;

	printf("Perimeter = %d\n", perimeter);
	return 0;
}

