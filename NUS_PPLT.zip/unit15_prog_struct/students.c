#include <stdio.h>
#include <string.h>

#define MSSV_LENGTH 9
#define TENSV_LENGTH 100

typedef struct{
    char mssv[MSSV_LENGTH];
    char tensv[TENSV_LENGTH];
    char gioi_tinh; //M: Male; F: Female
} sinh_vien;

void nhap_sinh_vien(sinh_vien *);
void in_sinh_vien(sinh_vien);
sinh_vien nhap_sv(void);

int main (void){
    sinh_vien sv1;
    //nhap_sinh_vien(&sv1);
    sv1 = nhap_sv();
    printf("IN ben ngoai ham nhap_sinh_vien");
    in_sinh_vien(sv1);
}

void nhap_sinh_vien_case_1(sinh_vien *sv){
    int len;
    printf("Nhap thong tin sinh vien\n");
    
    printf("Nhap MSSV: ");
    fgets((*sv).mssv, MSSV_LENGTH, stdin);
    len = strlen((*sv).mssv);
	if ((*sv).mssv[len - 1] == '\n') 
        (*sv).mssv[len - 1] = '\0';
    
    getchar();
    printf("Nhap Ten Sinh Vien: ");
    fgets((*sv).tensv, TENSV_LENGTH, stdin);
    len = strlen((*sv).tensv);
	if ((*sv).tensv[len - 1] == '\n') (*sv).tensv[len - 1] = '\0';
    
    //getchar();
    printf("Nhap Gioi Tinh: ");
    (*sv).gioi_tinh = getchar();

    in_sinh_vien(*sv);
}

void nhap_sinh_vien(sinh_vien *sv){
    int len;
    printf("Nhap thong tin sinh vien\n");
    
    printf("Nhap MSSV: ");
    fgets(sv->mssv, MSSV_LENGTH, stdin);
    len = strlen(sv->mssv);
	if (sv->mssv[len - 1] == '\n') 
        sv->mssv[len - 1] = '\0';
    
    getchar();
    printf("Nhap Ten Sinh Vien: ");
    fgets(sv->tensv, TENSV_LENGTH, stdin);
    len = strlen(sv->tensv);
	if (sv->tensv[len - 1] == '\n') sv->tensv[len - 1] = '\0';
    
    //getchar();
    printf("Nhap Gioi Tinh: ");
    sv->gioi_tinh = getchar();

    in_sinh_vien(*sv);
}

sinh_vien nhap_sv(void){
    sinh_vien sv;

    int len;
    printf("Nhap thong tin sinh vien\n");
    
    printf("Nhap MSSV: ");
    fgets(sv.mssv, MSSV_LENGTH, stdin);
    len = strlen(sv.mssv);
	if (sv.mssv[len - 1] == '\n') 
        sv.mssv[len - 1] = '\0';
    
    getchar();
    printf("Nhap Ten Sinh Vien: ");
    fgets(sv.tensv, TENSV_LENGTH, stdin);
    len = strlen(sv.tensv);
	if (sv.tensv[len - 1] == '\n') sv.tensv[len - 1] = '\0';
    
    //getchar();
    printf("Nhap Gioi Tinh: ");
    sv.gioi_tinh = getchar();

    in_sinh_vien(sv); 

    return sv;      
}

void in_sinh_vien(sinh_vien sv){
    printf("Thong tin sinh vien\n");
    printf("MSSV: %s", sv.mssv);
    printf("TenSV: %s", sv.tensv);
    printf("Gioi tinh %c", sv.gioi_tinh);
    printf("\n");
}



