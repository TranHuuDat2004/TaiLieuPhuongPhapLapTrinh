// Unit16_StringIO2.c 
#include <stdio.h>
#include <string.h>
#define LENGTH 50

int main(void) {
	char str[LENGTH];
	int len;

	printf("Enter string (at most %d characters): ", LENGTH-1);
	fgets(str, LENGTH, stdin);//use stream get str include space

	len = strlen(str);	
	if (str[len - 1] == '\n')		
		str[len - 1] = '\0';

	printf("str = ");
	puts(str);

	return 0;
}

