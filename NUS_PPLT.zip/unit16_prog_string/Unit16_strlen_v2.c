// Unit16_strlen_v2.c 
#include <stdio.h>

int mystrlen(char *);

int main(void) {
	char str[80];

	printf("Enter string: ");
	scanf("%s", str);
	printf("length = %d\n", mystrlen(str));

	return 0;
}

int mystrlen(char *p) {
	int count = 0;

	while (*p++) {
		count++;
	}
	return count;
}

