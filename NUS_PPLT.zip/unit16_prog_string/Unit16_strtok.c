// Unit16_strtok.c
// This program illustrates the use of strtok().
// Taken from http://www.tutorialspoint.com/c_standard_library/c_function_strtok.htm
#include <string.h>
#include <stdio.h>

int main(void) {
	char str[80] = "This is - www.tutorialspoint.com - website";// add '\0'
	char s[2] = "-";//add '\0'
	char *token;//pointer to char

    /* get the first token */
	token = strtok(str, s);//string tokenizer

	/* walk through other tokens */
    while (token != NULL) {
		printf("%s\n", token);
		token = strtok(NULL, s);
	}
	
    return 0;
}

