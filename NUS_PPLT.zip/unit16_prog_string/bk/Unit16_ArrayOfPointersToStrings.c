// Unit16_ArrayOfPointersToStrings.c 
#include <stdio.h>

int main(void) {
	char *fruits[] = { "apple", "banana", "cherry" };
	int i;

	fruits[0] = "pear";
	for (i=0; i<3; i++) {
		printf("%s\n", fruits[i]);
	}

	return 0;
}

