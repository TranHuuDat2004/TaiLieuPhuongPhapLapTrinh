// Unit16_ArrayOfStrings.c 
#include <stdio.h>

int main(void) {
	char fruits[][6] = {"apple", "mango", "pear"};
	// char fruits[3][6] = {"apple", "mango", "pear"};

	printf("fruits: %s %s\n", fruits[0], fruits[1]);
	printf("character: %c\n", fruits[2][1]);

	return 0;
}

