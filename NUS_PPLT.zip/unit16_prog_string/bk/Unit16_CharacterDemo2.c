// Unit16_CharacterDemo2.c 
#include <stdio.h>

int main(void) {
	char ch;

	printf("Enter a character: ");
	ch = getchar();

	printf("Character entered is ");
	putchar(ch);
	putchar('\n');

	return 0;
}

