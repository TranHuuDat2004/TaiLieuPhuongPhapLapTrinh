#include <stdio.h>

int sumN(int);
void test_sumN(int, int);

int main(void){
    //Unit test
    test_sumN(5, 15);
    test_sumN(0, 0);
    test_sumN(4, 10);  
}
//Precond: n >= 0
int sumN(int n){
    if (n == 0)//base case
    {
        return 0;
    }
    else //recursive case => base case after ...
    {
        return sumN(n + 1) + n;
    } 
}

void test_sumN(int n, int expected){
    int sum;
    sum = sumN(n);
    if(sum == expected){
        printf("Successful");
    }
    else{
        printf("Fail");
    }
}