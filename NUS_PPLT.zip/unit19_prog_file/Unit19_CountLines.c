// Unit19_CountLines.c 
#include <stdio.h>

#define FILENAME_LENGTH 8
#define MAX_LINE_LENGTH 80

int countLines(char []);

int main(void) {
	char input_filename[FILENAME_LENGTH+1]; 

	printf("What is the input filename? ");
	scanf("%s", input_filename);

	printf("Number of lines = %d\n", countLines(input_filename));

	return 0;
}

int countLines(char filename[]) {
	FILE *fp;
	int  count = 0;
	char s[MAX_LINE_LENGTH+1];

	if ((fp = fopen(filename, "r")) == NULL) 
		return -1;  // error 

	while (fgets(s, MAX_LINE_LENGTH+1, fp) != NULL) 
		count++;

	if (!feof(fp))	// read error encountered
		count = -1;  

	fclose(fp); 
	return count;
}

