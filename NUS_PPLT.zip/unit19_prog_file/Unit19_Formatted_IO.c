// Unit19_Formatted_IO.c 
#include <stdio.h>

int main(void) {
	FILE *infile, *outfile;
	char x;
	int y;
	float z;

	infile = fopen("formatted.in", "r");
	outfile = fopen("formatted.out", "w");

	fscanf(infile, "%c %d %f", &x, &y, &z);
	fprintf(outfile, "Data read: %c %d %.2f\n", x, y, z);

	fclose(infile);
	fclose(outfile);
	return 0;
}

