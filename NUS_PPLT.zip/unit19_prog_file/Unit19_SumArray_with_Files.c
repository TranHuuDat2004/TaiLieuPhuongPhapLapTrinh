// Unit19_SumArray_with_Files.c 
#include <stdio.h>
#include <stdlib.h>
#define MAX 10   // maximum number of elements

int scanPrices(float []);
float sumPrices(float [], int);
void printResult(float);

int main(void) {
	float prices[MAX]; 
	int size = scanPrices(prices);
	printResult(sumPrices(prices, size));

	return 0;
}

// Compute sum of elements in arr
float sumPrices(float arr[], int size) {
	float sum = 0.0;
	int i;

	for (i=0; i<size; i++)
		sum += arr[i];

	return sum;
}

// Read number of prices and prices into array arr.
// Return number of prices read.
int scanPrices(float arr[]) {
	FILE *infile;
	int size, i;

	// Open a file for reading
	if ((infile = fopen("prices.in", "r")) == NULL) { 
		printf("Cannot open file \"prices.in\"\n");
		exit(1);
	}
	fscanf(infile, "%d", &size);

	for (i=0; i<size; i++) 
		fscanf(infile, "%f", &arr[i]);

	fclose(infile);
	return size;
}

// Print the total price
void printResult(float total_price) {
	FILE *outfile;

	outfile = fopen("prices.out", "w"); // open a file for writing
	fprintf(outfile, "Total price = $%.2f\n", total_price);
	fclose(outfile);
}

