// Unit19_feof.c 
// Demo on Formatted I/O with feof()
#include <stdio.h>
#include <stdlib.h>

int main(void) {
	FILE *infile;
	int num;

	if ((infile = fopen("feof.in", "r")) == NULL) {
		printf("Cannot open file \"feof.in\"\n");
		exit(1);
	}

	while (!feof(infile)) {
		fscanf(infile, "%d", &num);
		printf("Value read: %d\n", num);
	}

	fclose(infile);
	return 0;
}

