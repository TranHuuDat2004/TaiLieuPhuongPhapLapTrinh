// Unit20_SortModules.c
#include <stdio.h>
#define MAX_MODULES 10   // maximum number of modules
#define CODE_LENGTH 7    // length of module code

typedef struct {
	char code[CODE_LENGTH+1];
	int  enrolment;
} module_t;

int scanModules(module_t []);
void printModules(module_t [], int);
void sortByEnrolment(module_t [], int);

int main(void) {
	module_t modules[MAX_MODULES];  
	int num_modules;

	num_modules = scanModules(modules);
	sortByEnrolment(modules, num_modules);
	printModules(modules, num_modules);

	return 0;
}

// Read number of modules, and for each module, 
// the module codes and enrolment figures.
// Return number of modules.
int scanModules(module_t mod[]) {
	int size, i;

	printf("Enter number of modules: ");
	scanf("%d", &size);

	printf("Enter module codes and student enrolment:\n");
	for (i=0; i<size; i++) 
		scanf("%s %d", mod[i].code, &mod[i].enrolment);

	return size;
}

// Sort by number of students 
// This uses Selection Sort
void printModules(module_t mod[], int size) {
	int i;

	printf("Sorted by student enrolment:\n");
	for (i=0; i<size; i++)
		printf("%s\t%3d\n", mod[i].code, mod[i].enrolment);
}

// Sort by number of students in each module
void sortByEnrolment(module_t mod[], int size) {
	int i, start, min_index;
	module_t temp;

	for (start = 0; start < size-1; start++) {
		// find index of minimum element
		min_index = start;
		for (i = start+1; i < size; i++)
			if (mod[i].enrolment < mod[min_index].enrolment)
				min_index = i;

		// swap minimum element with element at start index
		temp = mod[start];
		mod[start] = mod[min_index];
		mod[min_index] = temp;
	}
}

