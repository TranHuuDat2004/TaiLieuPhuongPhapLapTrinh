// Unit3_prog1.c
// This program computes the average of 3 integers
#include <stdio.h>

int main(void) {
	// int num1, num2, num3;
	// float ave;

	// printf("Enter 3 integers: ");
	// scanf("%d %d %d", &num1, &num2, &num3);

	// ave = (num1 + num2 + num3) / 3.0;
	// printf("Average = %d\n", ave);

	// return 0;
	double one_seventh = 1.0/7.0;
	double f = 0.0;

	while (f >= 1.0)
	{
		printf("%f\n", f);
		f += one_seventh;
	} 

	int a = 123;
	printf("a = %d\n", a);
	printf("&a = %p\n", &a);
	//printf("Hello C");
}

