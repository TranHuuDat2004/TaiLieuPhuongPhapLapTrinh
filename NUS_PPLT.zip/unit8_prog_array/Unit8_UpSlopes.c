// Unit8_UpSlopes.c
// This program computes the number of up-slopes in a route given
// as a list of non-negative values representating the heights
// at regular interval on the route.

#include <stdio.h>
#define MAX 100 // maximum length of a route

int read_route(float []);
int compute_upslopes(float [], int);

int main(void) {
	float route[MAX];
	int route_length;

	route_length = read_route(route);
	printf("Number of up-slopes = %d\n", compute_upslopes(route, route_length));
	return 0;
}

// This function reads a list of non-negative values representing
// the heights of a route at regular interval into array route. 
// It terminates when a negative value is encountered.
int read_route(float route[]) {
	float height;
	int length = 0; // length of route; number of values read into array

	printf("Enter data: ");
	scanf("%f", &height);
	while (height >= 0) {
		route[length++] = height;
		scanf("%f", &height);
	}
	return length;
}

// This function takes a route and computes the number of upslopes.
// Complete this function
int compute_upslopes(float route[], int size) {
	int upslopes = 0; // number of upslopes




	return upslopes;
}

