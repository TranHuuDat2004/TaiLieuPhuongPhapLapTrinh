//Pre-processor
#include <stdio.h>
#define PI 3.14;

//Prototype
int minPairDiff(int [], int);
void testMinPairDiff(int[], int, int);
int findMin01(int [], int);
int findMin02(int [], int);

//Main function
int main(void){
    int numbers01[] = { 20, 12, 25, 8, 36, 9 };
    testMinPairDiff(numbers01, 6, 1);

    int numbers02[] = { 431, 945, 64, 841, 783, 107, 598 };
    testMinPairDiff(numbers02, 7, 43);

    int numbers03[] = {3, 5, 7};
    testMinPairDiff(numbers03, 3, 2);
}

//Define functions
/*
    Precond: size >= 2
 */
int findMin02(int arr[], int size){
    int min01 = findMin01(arr, size);
    int minValue;
    int i;
    for(i = 0; i < size; i++)
    {
        if( arr[i] != min01){
            minValue = arr[i];
            break;
        }
    }
    for(i = 1; i < size; i++){
        if( arr[i] < minValue && arr[i] != min01){
            minValue = arr[i];
        }
    }    

    return minValue;
}

/*
    Precond: size >= 1
 */
int findMin01(int arr[], int size){
    int i = 0;
    int minValue = arr[0];
    
    for(i = 1; i < size; i++){
        if( arr[i] < minValue){
            minValue = arr[i];
        }
    }

    return minValue;
}

/*
    Precond: size >= 2
 */
int minPairDiff(int arr[], int size){
    return findMin02(arr, size) - findMin01(arr, size);
}
 
//Unit Test
void testMinPairDiff(int numbers[], int size, int expectedValue){
    int result = minPairDiff(numbers, size);
    if( result == expectedValue ){
        printf("OK\n");
    }
    else{
        printf("Error\n");
    }
}