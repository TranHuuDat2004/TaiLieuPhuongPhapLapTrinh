#include <stdio.h>
#include <stdlib.h>

#define MAX_ARRAY 100 
#define SIZE01 3
#define SIZE02 2

void printArray(int[], int);
void scanArray(int[], int);
int* mergeArray(int[], int, int[], int);

int main (void){
    int result[SIZE01 + SIZE02];

    int input1[SIZE01];
    scanArray(input1, SIZE01);

    int input2[SIZE02];
    scanArray(input2, SIZE02);

    int i;
    int j = 0;

    for(i = 0; i < SIZE01; i++ ){
        result[j] = input1[i];
        j = j + 1;
    }

    for(i = 0; i < SIZE02; i++){
        result[j] = input2[i];
        j = j + 1;
    }

    //printArray(result, SIZE01 + SIZE02);

    int* result2 = mergeArray(input1, SIZE01, input2, SIZE02);
    printArray(result2, SIZE01 + SIZE02);
}

void printArray(int arr[], int size){
    int i;
    printf("Array: ");
    for(i = 0; i < size; i++){
        printf("%d ", arr[i]);
    }
}

void scanArray(int arr[], int size){
    int i;

    printf("Input Array");
    for(i = 0; i < size; i++){
        scanf("%d\n", &arr[i]);    
    }
}

int* mergeArray(int arr1[], int size1, int arr2[], int size2){
    int i;
    int j;
    int *result;

    result = calloc((size1 + size2), sizeof(int));

    for(i = 0; i < size1; i++ ){
        result[j] = arr1[i];
        j = j + 1;
    }

    for(i = 0; i < size2; i++){
        result[j] = arr2[i];
        j = j + 1;
    }

    return result;
}
