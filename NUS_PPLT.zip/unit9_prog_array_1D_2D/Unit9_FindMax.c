// Unit9_FindMax.c
#include <stdio.h>
#define SIZE 50    

void scanArray(int [], int);
void printArray(int [], int);

int findMax(int [], int);
int findMin(int [], int);
int sum(int [], int);
int sumEven(int [], int);
int isEven(int);

int main(void) {
	int numbers[SIZE];
	int max;

	scanArray(numbers, 5);

	max = findMax(numbers, 5);
	
	printArray(numbers, 5);
	printf("\nMax value: %d", max);

	return 0;
}

// Compute maximum value in array
// Precond: size >= 0
int findMax(int arr[], int size) {
	int i; 
	int maxValue;

	maxValue = arr[0];
	for (i = 1; i < size; i++) 
		if (arr[i] > maxValue)
			maxValue = arr[i];

	return maxValue;
}

int findMin(int arr[], int size){
	int min = arr[0];
	int i;

	for(i = 0; i < size; i++){
		if(arr[i] < min){
			min = arr[i];
		}
	}

	return min;
}

void scanArray(int arr[], int size)
{
	int i;
	int temp;

	for(i = 0; i < size; i++)
	{
		printf("Input %d: ", i + 1);
		scanf("%d", &temp);
		arr[i] = temp;
	}
}

void printArray(int arr[], int size){
	int i;

	printf("Print Array: ");
	for(i = 0; i < size; i++){
		printf("%d ", arr[i]);
	}
}

/*
	Sum of values in arr.
	Precondition: size >= 0;
 */
int sum(int arr[], int size){
	int i;
	int result;

	for(i = 0; i < size; i++){
		result += arr[i];
	}

	return result;
}

/*
	1: num is even number
	0: num is not even number
 */
int isEven(int num){
	if(num%2 == 0){
		return 1;
	}
	else{
		return 0;
	}
}

int sumEven(int arr[], int size){
	int i;
	int result = 0;

	for(i = 0; i < size; i++){
		if(isEven(arr[i]) == 1){
			result += arr[i];
		}
	}

	return result;	
}

