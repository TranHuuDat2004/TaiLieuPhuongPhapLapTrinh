// Unit9_Pyramid_complete.c
// This program computes the maximum-value path
// in a triangular matrix.

#include <stdio.h>
#define MAX_ROWS 10

int maxPathValue(int [][MAX_ROWS], int);
int scanTriangularArray(int [][MAX_ROWS]);
void printTriangularArray(int [][MAX_ROWS], int);

int main(void) {
	int size;       // number of rows in the pyramid
	int table[MAX_ROWS][MAX_ROWS];

	size = scanTriangularArray(table);
	// printTriangularArray(table, size);   // for checking

	printf("Maximum path value = %d\n", maxPathValue(table, size));

	return 0;
}

// Read data into the 2-dimensional triangular array arr,
// and return the number of rows in the array.
int scanTriangularArray(int arr[][MAX_ROWS]) {
	int num_rows, r, c;

	printf("Enter number of rows: ");
	scanf("%d", &num_rows);

	printf("Enter values for array: \n");
	for (r = 0; r < num_rows; r++) {
		for (c = 0; c <= r; c++) {
			scanf("%d", &arr[r][c]);
		}
	}

	return num_rows;
}

// Print elements in the 2-dimensional triangular array arr.
// For checking purpose.
void printTriangularArray(int arr[][MAX_ROWS], int size) {
	int r, c;

	for (r = 0; r < size; r++) {
		for (c = 0; c <= r; c++) {
			printf("%d\t", arr[r][c]);
		}
		printf("\n");
	}
}

// Compute the maximum path sum.
int maxPathValue(int arr[][MAX_ROWS], int size) {



	return 123;
}

